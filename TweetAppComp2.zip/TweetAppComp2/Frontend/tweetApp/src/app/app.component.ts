import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from './service/authentication.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'tweetApp';

  ngOnInit(): void {
    this.loggedIn();
    this.router.navigate(['login']);
  }
  constructor( public router: Router,private authService:AuthenticationService) {
  }

  isLoggedIn: boolean = false;

  loggedIn(): boolean {
    if (!this.authService.loggedInUser.loggedOut) {
      this.isLoggedIn = true;
      return true
    }
    else {
      this.isLoggedIn = false;
      return false;
    }
  }

  exit(){
    window.location.reload();
  }
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TweetService } from '../service/tweet.service';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-my-tweets',
  templateUrl: './my-tweets.component.html',
  styleUrls: ['./my-tweets.component.css']
})
export class MyTweetsComponent implements OnInit {

  tweet: any;
  constructor(private tweetService: TweetService, private router: Router) { }

  ngOnInit(): void {
    this.tweetService.getMyTweets().subscribe(response => {
      this.tweet = response;
    });
  }

  delete(index: any) {
    this.tweetService.deleteTweet(index).subscribe(response => {
      this.ngOnInit();
    }, (error) => {
      this.ngOnInit();
    }
    );
  }

}

export interface Reply {
    reply: any;
    loginId:string;
    tweetId:any;
}
export interface Tweet {
    tweet: any;
    loginId:string;
}
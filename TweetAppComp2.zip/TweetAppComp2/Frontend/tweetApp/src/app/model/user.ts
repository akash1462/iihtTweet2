export interface User {
    loginId:string;
    email:string;
    active:boolean;
    confirmedSignUp:boolean;
    contactNumber:number;
    firstName:string;
    lastName:string;
    password:string;
    resetPassword:boolean;
    contact:number;
}

import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { UserService } from './user.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  user: boolean;

  constructor(private _httpClient: HttpClient, private userService: UserService, public router: Router) { }

  private authenticationApiUrl = environment.baseUrl;
  private token: string;
  username: string;
  loggedInUser = { loggedOut: true };
  redirectUrl = '/';
  loggedIn: boolean = false;
  id:number;
  type:string;

  public setToken(token: string) {
    this.token = token;
  }
  public getToken() {
    return this.token;
  }

  authenticate(user: string, password: string): Observable<any> {
    let headers = new HttpHeaders();
    headers = headers.set('Authorization', 'Basic ' + user);
    return this._httpClient.get(this.authenticationApiUrl + "api/v1.0/tweets/user/login/" + user);
  }

  logout() {
    this.loggedInUser = { loggedOut: true };
    this.loggedIn = false;
    this.router.navigate(['login']);
  }

}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Reply } from '../model/reply';
import { Tweet } from '../model/tweet';
import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})
export class TweetService {
  url: string = environment.baseUrl ;
  constructor(private router: Router, private _httpClient: HttpClient, private authService:AuthenticationService) { }

  addTweet(tweet: Tweet) :Observable<any> {
    console.log("tweet" + tweet)
    return this._httpClient.post<any>(this.url + "api/v1.0/tweets/" + this.authService.username+ "/add", tweet);
  }

  getAllTweets() :Observable<any> {
    return this._httpClient.get<any>(this.url + "api/v1.0/tweets/all");
  }

  getMyTweets() {
    return this._httpClient.get(this.url +"api/v1.0/tweets/" + this.authService.username);
  }

  deleteTweet(index: any) {
    return this._httpClient.delete( this.url + "/api/v1.0/tweets/"+ this.authService.username + "/delete/" + index);
  }

   postcomments(reply:any) {
    console.log(this.url + "api/v1.0/tweets/"+ this.authService.username + "/reply/" + reply.tweetId,reply)
    return this._httpClient.post( this.url + "api/v1.0/tweets/"+ this.authService.username + "/reply/" + reply.tweetId,reply);
  }

}

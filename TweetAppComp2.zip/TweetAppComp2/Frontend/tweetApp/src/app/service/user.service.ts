import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { User } from '../model/user';
import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  url: string = environment.baseUrl ;
 
  users = [  ];

  constructor(private router: Router, private _httpClient: HttpClient) { }

  addUser(user: User) :Observable<any> {
    return this._httpClient.post<any>(this.url + "api/v1.0/tweets/register", user);
    this.router.navigate(['login']);
  }

  resetPassword(user: User) :Observable<any> {
    return this._httpClient.put<any>(this.url + "api/v1.0/tweets/" +  user.loginId + "/forgot", user);
    this.router.navigate(['login']);
  }

  getAllUsers() {
    return this._httpClient.get(this.url + "/api/v1.0/tweets/users/all");
  }

}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/model/user';
import { AuthenticationService } from 'src/app/service/authentication.service';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {
  resetPassword: FormGroup;
  user: User;

  constructor(public router: Router, private authService: AuthenticationService, private formBuilder: FormBuilder, private userService: UserService) {
  }

  get password() {
    return this.resetPassword.get('password');
  }
  get confirmPassword() {
    return this.resetPassword.get('confirmPassword');
  }

  ngOnInit() {
    this.resetPassword = this.formBuilder.group({
      loginId: [this.authService.username],
      password: ['', [
        Validators.required
      ]],
      confirmPassword: ['', [
        Validators.required,
        this.matchConfirmPassword.bind(this)
      ]]
    })
  }

  matchConfirmPassword(formControl: FormControl): { [s: string]: boolean } {
    if (this.resetPassword) {
      if (formControl.value && formControl.value.length > 0 && formControl.value !== this.resetPassword.get('password').value) {
        return { 'nomatch': true };
      }
    }
    return null;
  }

  onSubmit() {
    this.user = {
      email: null,
      active: null,
      confirmedSignUp: null,
      contactNumber: null,
      firstName: null,
      lastName: null,
      contact: null,
      resetPassword: null,
      loginId: this.resetPassword.value['loginId'],
      password: this.resetPassword.value['password']
    };
    this.userService.resetPassword(this.user).subscribe(data => {
      this.router.navigate(['home'])
      window.alert("Password Reset Success");
    },
    error => {
      console.log("error");
    });
  }
}

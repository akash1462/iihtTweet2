import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/model/user';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signUpForm: FormGroup;
  user: User;
  userCreated: boolean;
  error: string;
  switch:boolean=false;
  optionvalue:string;
  
  constructor(private formBuilder: FormBuilder, private userService: UserService,private router: Router) { }
  get loginId() {
    return this.signUpForm.get('loginId');
  }

  get email(){
    return this.signUpForm.get('email');
  }

  get contact(){
    return this.signUpForm.get('contact');
  }
  get firstname() {
    return this.signUpForm.get('firstname');
  }
  get lastname() {
    return this.signUpForm.get('lastname');
  }
  get password() {
    return this.signUpForm.get('password');
  }
  get confirmPassword() {
    return this.signUpForm.get('confirmPassword');
  }
  
  ngOnInit() {
    this.signUpForm = this.formBuilder.group({
      loginId : ['',[
        Validators.required
      ]],
      email : ['',[
        Validators.required
      ]],
      contact :[''],
      firstname:['',[
        Validators.required
      ]],
      lastname:['',[
        Validators.required
      ]],
      password:['',[
        Validators.required
      ]],
      confirmPassword:['',[
        Validators.required,
        this.matchConfirmPassword.bind(this)
      ]]
    })
  }
  
  matchConfirmPassword(formControl: FormControl): { [s: string]: boolean } {
    if (this.signUpForm) {
      if (formControl.value && formControl.value.length > 0 && formControl.value !== this.signUpForm.get('password').value) {
        return { 'nomatch': true };
      }
    }
    return null;
  }

  addUser() {
    this.user = { 
    loginId:this.signUpForm.value['loginId'],     
    email:this.signUpForm.value['email'] , 
    active:null,
    confirmedSignUp:null,
    contactNumber:this.signUpForm.value['contact'],
    firstName:this.signUpForm.value['firstname'],
    lastName: this.signUpForm.value['lastname'],
    password:this.signUpForm.value['password'],
    contact:this.signUpForm.value['contact'],
    resetPassword:null
 
  };

    this.userService.addUser(this.user).subscribe(data => {
        this.router.navigate(['login'])
        window.alert("New User Created Successfully");
    },
      error => {
        console.log("error")
        if (error.status == 500) {
          this.error = "User Already Exists";
        }
        console.log(this.error);
      }
    );
  }
  
}

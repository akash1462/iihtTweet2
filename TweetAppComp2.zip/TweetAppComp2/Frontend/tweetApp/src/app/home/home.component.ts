import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Reply } from '../model/reply';
import { Tweet } from '../model/tweet';
import { AuthenticationService } from '../service/authentication.service';
import { TweetService } from '../service/tweet.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  postTweet: FormGroup;
  tweet: any;
  tweets: any;
  likeArray: Array<boolean> = [];
  replyDesc: String;
  // reply: Reply;
  reply: Array<boolean> = [];

  constructor(public router: Router, private formBuilder: FormBuilder, private tweetService: TweetService, private AuthService: AuthenticationService) {
  }


  ngOnInit() {
    this.postTweet = this.formBuilder.group({
      tweetDesc: ['',[
        Validators.required
      ]]
    });
    this.tweetService.getAllTweets().subscribe(response => {
      this.tweets=response;
      this.tweets.forEach((tweet: any) => {
        tweet.date;
        this.likeArray.push(false);
        this.replyDesc = '';
      });
  })
   
  }

  get tweetDesc() {
    return this.postTweet.get('tweetDesc');
  }

  onSubmit() {
    this.tweet = {
      loginId: this.AuthService.username,
      tweet: this.postTweet.value['tweetDesc'],
      date: new Date().toISOString()
    };
    console.log(this.tweet)
    this.tweetService.addTweet(this.tweet).subscribe(data => {
      window.alert("Tweet Created success");
      this.postTweet.reset();
    },
    error => {
      console.log("error");
    });
  }
  
  like(index: any) {
    this.likeArray[index] = true;
  }

  unlike(index: any) {
    this.likeArray[index] = false;
  }

  postcomment(index: any, i: any) {
    const request = ({
      tweetId: index,
      reply: this.replyDesc
    });
    this.tweetService.postcomments(request).subscribe((response: any) => {
    }, (error) => {
      console.log(error);
      this.ngOnInit();
      this.reply[i] = false;
    })
  }

}

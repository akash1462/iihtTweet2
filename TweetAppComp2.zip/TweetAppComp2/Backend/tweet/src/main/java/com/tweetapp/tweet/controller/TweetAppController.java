package com.tweetapp.tweet.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.tweet.model.Tweet;
import com.tweetapp.tweet.model.User;
import com.tweetapp.tweet.service.TweetService;
import com.tweetapp.tweet.service.UserService;
import com.tweetapp.tweet.model.ReplyTweet;

@RestController
@CrossOrigin("*")
public class TweetAppController {

	@Autowired 
	TweetService tweetService;
	
	@Autowired 
	UserService userService;
	
	@GetMapping("/api/v1.0/tweets/all")
	public ResponseEntity<List<Tweet>> getAllUserTweets() throws Exception {
		return new ResponseEntity<>(tweetService.getTweetsOfAllUser(), HttpStatus.OK);
	}
	
	@GetMapping("/api/v1.0/tweets/{username}")
	public ResponseEntity<List<Tweet>> getAllTweetsOfTheUser(@PathVariable("username") String userName) {
		return new ResponseEntity<>(tweetService.findTweetsByUserName(userName), HttpStatus.OK);
	}
	
	@PostMapping("/api/v1.0/tweets/{username}/add")
	public ResponseEntity<?> postUserTweet(@PathVariable String username, @RequestBody Tweet tweet) throws Exception {

		if (username != null && tweet.getLoginId() != null && username.equalsIgnoreCase(tweet.getLoginId())) {
			Tweet postUserTweets = tweetService.postUserTweets(tweet);
			return new ResponseEntity<>(postUserTweets, HttpStatus.OK);
		} else {
			return null;
		}
	}
	
	@PutMapping("/api/v1.0/tweets/{username}/update/{id}")
	public ResponseEntity<?> updateUserTweet(@PathVariable String username, @PathVariable String id,
			@RequestBody Tweet data) throws Exception {
		tweetService.updateUserTweet(username, id, data);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@DeleteMapping("/api/v1.0/tweets/{username}/delete/{id}")
	public ResponseEntity<?> deleteUserTweet(@PathVariable String username, @PathVariable String id) {
		tweetService.deleteUserTweet(id);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@PutMapping("/api/v1.0/tweets/{username}/like/{id}")
	public void likeUserTweet(@PathVariable String username, @PathVariable String id) {
		tweetService.likeUserTweet(id, username);
	}

	@PostMapping("/api/v1.0/tweets/{username}/reply/{id}")
	public void userReplyTweet(@PathVariable String username, @PathVariable String id,
			@RequestBody ReplyTweet replyTweet) {
		System.out.println("inside controller"+username + id + replyTweet);
		tweetService.replyUserTweet(username, id, replyTweet);
	}
	
	@PutMapping("/api/v1.0/tweets/{username}/forgot")
	public void forgotPassword(@RequestBody User user) throws Exception {
		userService.forgotUserPassword(user);
	}

	@PostMapping("/api/v1.0/tweets/register")
	public void newUserRegistration(@RequestBody User user) {
		System.out.println("new user register");
		userService.userRegistration(user);
	}

	@GetMapping("/api/v1.0/tweets/users/all")
	public ResponseEntity<List<User>> getAllUsers() {
		return new ResponseEntity<>(userService.getAllUsers(), HttpStatus.OK);
	}

	@GetMapping("/api/v1.0/tweets/user/search/{username}")
	public ResponseEntity<?> searchUserByUserName(@PathVariable String username) {
		List<User> user = userService.searchUserByUserName(username);
		return new ResponseEntity<>(user, HttpStatus.OK);
	}
	
	@GetMapping("/api/v1.0/tweets/user/login/{username}")
	public User login(@PathVariable String username) {
		User user = userService.getDetailsById(username);
		return user;
	}
}

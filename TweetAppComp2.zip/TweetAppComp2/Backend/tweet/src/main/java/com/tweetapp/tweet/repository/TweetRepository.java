package com.tweetapp.tweet.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.DeleteQuery;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.tweetapp.tweet.model.Tweet;

public interface TweetRepository extends MongoRepository<Tweet, String>{

	List<Tweet> findByLoginId(String string);

	Tweet findByTweetId(String tweetId);

	@DeleteQuery
	long deleteByTweetId(String tweetId);
	
}

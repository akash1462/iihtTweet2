package com.tweetapp.tweet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.tweetapp.tweet.model.User;
import com.tweetapp.tweet.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	MongoTemplate mongoTemplate;

	public void userRegistration(User data) {
		System.out.println(data);
		userRepository.save(data);
	}

	public User getDetailsByEmail(String userName) {
		User user = userRepository.findByEmail(userName);
		return user;
	}
	
	public User getDetailsById(String userName) {
		User user = userRepository.findByLoginId(userName);
		return user;
	}

	public void forgotUserPassword(User user) throws Exception {
		Query query = new Query();
		query.addCriteria(Criteria.where("loginId").is(user.getLoginId()));
		Update update = new Update();
		update.set("password", user.getPassword());
		mongoTemplate.updateFirst(query, update, User.class);

	}

	public List<User> searchUserByUserName(String userName) {
		Query query = new Query();
		query.addCriteria(Criteria.where("loginId").regex("^" + userName));
		List<User> user = mongoTemplate.find(query, User.class);
		return user;
	}

	public List<User> getAllUsers() {
		List<User> user = userRepository.findAll();
		return user;
	}
}

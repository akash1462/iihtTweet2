package com.tweetapp.tweet.model;

public class ReplyTweet {
	String reply;

	public String getReply() {
		return reply;
	}

	public void setReply(String reply) {
		this.reply = reply;
	}
}

package com.tweetapp.tweet.service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.tweetapp.tweet.model.ReplyTweet;
import com.tweetapp.tweet.model.Tweet;
import com.tweetapp.tweet.model.TweetReply;
import com.tweetapp.tweet.repository.TweetRepository;

@Service
public class TweetService {
	
	@Autowired
	TweetRepository tweetRepository;
	
	@Autowired
	MongoTemplate mongoTemplate;

	public void updateUserTweet(String username, String id, Tweet data) throws Exception {
		Query query = new Query();
		query.addCriteria(
				new Criteria().andOperator(Criteria.where("tweetId").is(id), Criteria.where("loginId").is(username)));
		Update update = new Update();
		update.set("tweet", data.getTweet());
		mongoTemplate.updateFirst(query, update, Tweet.class);

	}

	public List<Tweet> getTweetsOfAllUser() {
		List<Tweet> userTweet = tweetRepository.findAll();
		return userTweet;
	}

	public void deleteUserTweet(String tweetId) {
		tweetRepository.deleteByTweetId(tweetId);
	}

	public void likeUserTweet(String tweetId, String userName) {
		Tweet tweet = tweetRepository.findByTweetId(tweetId);
		List<String> likes = tweet.getLikes();
		likes.add(userName);
		int like = tweet.getLikeCount();
		like = like + 1;
		tweet.setLikeCount(like);
		tweet.setLikes(likes);
		tweetRepository.save(tweet);
	}

	public void replyUserTweet(String username, String tweetId, ReplyTweet replyTweet) {
		Tweet tweet = tweetRepository.findByTweetId(tweetId);
		System.out.println("//////" +tweet.getReply());
		TweetReply tweetReply = new TweetReply();
		tweetReply.setUsername(username);
		tweetReply.setReply(replyTweet.getReply());
		System.out.println("service method end" + tweet.getReply());
		tweet.getReply().add(tweetReply);
		tweetRepository.save(tweet);
	}

	public List<Tweet> findTweetsByUserName(String userName) {
		List<Tweet> userTweet = tweetRepository.findByLoginId(userName);
		return userTweet;
	}

	public  Tweet postUserTweets(Tweet tweet) {
		UUID uuid = UUID.randomUUID();
		tweet.setTweetId(uuid.toString());
		Tweet save = tweetRepository.save(tweet);
		return save;
		
	}
}
